import React, { useState } from 'react';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export const WomenCancerStats: React.FC = () => {
  const [chartType, setChartType] = useState<'bar' | 'pie'>('bar');

  const data = [
    { name: '유방암', cases: 2296840, percentage: 23.8, color: '#FF6B9D' },
    { name: '폐암', cases: 908630, percentage: 9.4, color: '#C44569' },
    { name: '대장암', cases: 856979, percentage: 8.9, color: '#A55EEA' },
    { name: '자궁경부암', cases: 662301, percentage: 6.9, color: '#778BEB' },
    { name: '갑상선암', cases: 614729, percentage: 6.4, color: '#4B7BEC' },
    { name: '자궁내막암', cases: 420368, percentage: 4.4, color: '#45AAF2' },
    { name: '위암', cases: 341326, percentage: 3.5, color: '#26DE81' },
    { name: '기타', cases: 3546827, percentage: 36.7, color: '#A5B1C2' }
  ];

  const totalCases = 9660000;

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 border border-gray-300 rounded shadow-lg">
          <p className="font-bold text-gray-800">{payload[0].payload.name}</p>
          <p className="text-sm text-gray-600">
            발병자 수: {payload[0].payload.cases.toLocaleString()}명
          </p>
          <p className="text-sm text-gray-600">
            비중: {payload[0].payload.percentage}%
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full bg-white rounded-xl shadow-lg border border-gray-100 p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-serif text-heritage-900 mb-2 font-bold">
            세계 여성 암 발병률 통계
          </h1>
          <p className="text-sm text-gray-500 mb-2">
            GLOBOCAN 2024 발표 (2022년 확정 데이터)
          </p>
          <p className="text-lg font-semibold text-heritage-800">
            전 세계 여성 암 신규 환자: 약 {(totalCases / 1000000).toFixed(1)}백만 명
          </p>
        </div>

        {/* Chart Type Toggle */}
        <div className="flex justify-center gap-4 mb-8">
          <button
            onClick={() => setChartType('bar')}
            className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${
              chartType === 'bar'
                ? 'bg-heritage-900 text-white shadow-lg'
                : 'bg-haven-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            막대 차트
          </button>
          <button
            onClick={() => setChartType('pie')}
            className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${
              chartType === 'pie'
                ? 'bg-heritage-900 text-white shadow-lg'
                : 'bg-haven-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            파이 차트
          </button>
        </div>

        {/* Chart Container */}
        <div className="bg-haven-50 rounded-xl p-4 mb-8 h-[500px]">
          {chartType === 'bar' ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis 
                  dataKey="name" 
                  angle={-45}
                  textAnchor="end"
                  interval={0}
                  tick={{ fontSize: 12, fill: '#666' }}
                />
                <YAxis 
                  label={{ value: '발병자 수 (명)', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: '#666' } }}
                  tick={{ fontSize: 12, fill: '#666' }}
                />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: '#f5f5f5' }} />
                <Legend wrapperStyle={{ paddingTop: '20px' }} />
                <Bar dataKey="cases" name="발병자 수" radius={[4, 4, 0, 0]}>
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percentage }) => `${name} ${percentage}%`}
                  outerRadius={160}
                  fill="#8884d8"
                  dataKey="percentage"
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Data Table */}
        <div className="overflow-hidden rounded-xl border border-gray-200 mb-8">
          <table className="w-full text-sm text-left">
            <thead>
              <tr className="bg-heritage-900 text-white">
                <th className="px-6 py-4 font-bold">순위</th>
                <th className="px-6 py-4 font-bold">암 종류</th>
                <th className="px-6 py-4 font-bold text-right">발병자 수</th>
                <th className="px-6 py-4 font-bold text-right">비중</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {data.slice(0, 7).map((item, index) => (
                <tr key={index} className="hover:bg-haven-50">
                  <td className="px-6 py-4 font-medium text-gray-900">
                    {index + 1}위
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: item.color }}
                      ></div>
                      <span className="font-medium text-gray-800">{item.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right text-gray-600">
                    {item.cases.toLocaleString()}명
                  </td>
                  <td className="px-6 py-4 text-right font-bold text-heritage-900">
                    {item.percentage}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Key Insights */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-pink-50 rounded-xl p-6 border border-pink-100">
            <h3 className="font-bold text-pink-900 mb-2 flex items-center gap-2">
              <span className="text-xl">🎗️</span> 유방암
            </h3>
            <p className="text-sm text-pink-800 leading-relaxed">
              전 세계 185개국 중 157개국에서 <strong>여성 암 1위</strong>를 차지하며, 
              전체 여성 암 환자의 약 4명 중 1명(23.8%)이 유방암 환자입니다.
              조기 검진이 무엇보다 중요한 이유입니다.
            </p>
          </div>
          <div className="bg-blue-50 rounded-xl p-6 border border-blue-100">
            <h3 className="font-bold text-blue-900 mb-2 flex items-center gap-2">
              <span className="text-xl">💉</span> 자궁경부암
            </h3>
            <p className="text-sm text-blue-800 leading-relaxed">
              백신으로 예방 가능한 유일한 암임에도 불구하고 여전히 높은 발병률(6.9%)을 보입니다.
              정기적인 검진과 백신 접종을 통해 예방할 수 있습니다.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};